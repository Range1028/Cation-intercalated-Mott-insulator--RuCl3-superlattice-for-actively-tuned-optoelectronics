# simple_test_differences.py
"""
简化版测试不同NIR处理方法是否产生明显差异的脚本
不依赖数据加载器，使用模拟数据测试
"""

import numpy as np
import torch
import cv2
import matplotlib.pyplot as plt
import os

def create_mock_nir_data():
    """创建模拟的NIR数据进行测试"""
    # 创建一个有一定结构的测试图像，而不是纯随机
    h, w = 480, 640
    
    # 创建一个渐变背景
    y, x = np.meshgrid(np.linspace(0, 1, h), np.linspace(0, 1, w), indexing='ij')
    base = (x * 0.3 + y * 0.7) * 255
    
    # 添加一些噪声和结构
    noise = np.random.normal(0, 20, (h, w))
    
    # 添加一些"对象"（模拟雾中的物体）
    objects = np.zeros((h, w))
    for _ in range(10):
        cy, cx = np.random.randint(50, h-50), np.random.randint(50, w-50)
        r = np.random.randint(20, 80)
        y_obj, x_obj = np.ogrid[:h, :w]
        mask = (x_obj - cx)**2 + (y_obj - cy)**2 <= r**2
        objects[mask] = np.random.randint(100, 200)
    
    # 组合
    nir_gray = base + noise + objects
    nir_gray = np.clip(nir_gray, 0, 255).astype(np.uint8)
    
    # 转为3通道
    nir_3channel = np.stack([nir_gray]*3, axis=-1)
    
    return nir_3channel

def test_nir_processing_variants():
    """测试各种NIR处理变体"""
    print("=" * 60)
    print("测试NIR处理变体")
    print("=" * 60)
    
    # 使用模拟数据
    nir_np = create_mock_nir_data()
    print(f"输入NIR: shape={nir_np.shape}, 值域=[{nir_np.min()}, {nir_np.max()}]")
    
    # 转为灰度
    if len(nir_np.shape) == 3:
        nir_gray = cv2.cvtColor(nir_np, cv2.COLOR_RGB2GRAY)
    else:
        nir_gray = nir_np.copy()
    
    print(f"转换后灰度图: shape={nir_gray.shape}, 值域=[{nir_gray.min()}, {nir_gray.max()}]")
    
    # 1. RGB-only变体（全零）
    rgb_only = np.zeros_like(nir_np)
    
    # 2. Raw NIR变体（原始）
    raw_nir = nir_np.copy()
    
    # 3. Gauss-only变体（纯高斯滤波）
    gauss_filtered = cv2.GaussianBlur(nir_gray, (5, 5), 1.0)
    gauss_only = np.stack([gauss_filtered]*3, axis=-1)
    
    # 4. Device-weighted变体（器件加权 + 显著增强）
    device_filtered = cv2.GaussianBlur(nir_gray, (5, 5), 1.0)
    
    # 器件响应度 (这里是关键修改)
    responsivity = 0.003
    enhancement_factor = 50.0  # 显著增强因子
    
    device_responsive = device_filtered.astype(np.float32) * responsivity * enhancement_factor
    print(f"器件响应后: 均值={device_responsive.mean():.3f}, 范围=[{device_responsive.min():.1f}, {device_responsive.max():.1f}]")
    
    # 伽马校正
    device_gamma = np.power(device_responsive / 255.0, 0.8) * 255.0
    
    # 对比度增强
    device_contrast = cv2.convertScaleAbs(device_gamma, alpha=1.5, beta=15)
    
    # 确保范围
    device_final = np.clip(device_contrast, 0, 255)
    device_weighted = np.stack([device_final]*3, axis=-1)
    
    # 收集所有变体
    variants = {
        'RGB Only': rgb_only,
        'Raw NIR': raw_nir,
        'Gauss Only': gauss_only,
        'Device Weighted': device_weighted
    }
    
    # 打印统计信息
    print("\n" + "=" * 70)
    print("变体统计信息")
    print("=" * 70)
    print(f"{'变体名称':<15} {'均值':<10} {'标准差':<10} {'最小值':<10} {'最大值':<10}")
    print("-" * 70)
    
    for name, img in variants.items():
        mean_val = img.mean()
        std_val = img.std()
        min_val = img.min()
        max_val = img.max()
        print(f"{name:<15} {mean_val:<10.2f} {std_val:<10.2f} {min_val:<10.0f} {max_val:<10.0f}")
    
    # 计算变体间差异
    print("\n" + "=" * 60)
    print("变体间差异分析")
    print("=" * 60)
    
    variant_names = list(variants.keys())
    max_diff = 0
    min_diff = float('inf')
    critical_pairs = []
    
    for i in range(len(variant_names)):
        for j in range(i+1, len(variant_names)):
            name1, name2 = variant_names[i], variant_names[j]
            diff = np.mean(np.abs(variants[name1].astype(float) - variants[name2].astype(float)))
            print(f"{name1:<15} vs {name2:<15}: {diff:8.2f}")
            
            max_diff = max(max_diff, diff)
            if diff < min_diff:
                min_diff = diff
                
            # 检查关键配对的差异
            if (name1, name2) in [('Raw NIR', 'Gauss Only'), ('Gauss Only', 'Device Weighted'), 
                                 ('Raw NIR', 'Device Weighted')]:
                critical_pairs.append((name1, name2, diff))
    
    print(f"\n最大差异: {max_diff:.2f}")
    print(f"最小差异: {min_diff:.2f}")
    
    # 检查关键差异
    print("\n" + "=" * 60)
    print("关键配对差异检查")
    print("=" * 60)
    
    sufficient_diff = True
    threshold = 5.0
    
    for name1, name2, diff in critical_pairs:
        status = "✅ 足够" if diff > threshold else "❌ 不足"
        print(f"{name1} vs {name2}: {diff:.2f} ({status})")
        if diff <= threshold:
            sufficient_diff = False
    
    if sufficient_diff:
        print(f"\n✅ 所有关键变体间都有足够的差异 (>{threshold})")
        print("可以进行有效的对比评估")
    else:
        print(f"\n❌ 某些变体间差异不足 (<={threshold})")
        print("建议增加器件响应的增强因子")
    
    # 可视化
    create_visualization(variants)
    
    return variants, sufficient_diff

def create_visualization(variants):
    """创建可视化对比图"""
    print(f"\n创建可视化对比图...")
    
    fig, axes = plt.subplots(3, 4, figsize=(16, 12))
    
    for idx, (name, img) in enumerate(variants.items()):
        # 第一行：显示图像（取第一个通道）
        display_img = img[:,:,0] if len(img.shape) == 3 else img
        
        axes[0, idx].imshow(display_img, cmap='gray', vmin=0, vmax=255)
        axes[0, idx].set_title(f'{name}\n均值: {img.mean():.1f}', fontsize=10)
        axes[0, idx].axis('off')
        
        # 第二行：显示直方图
        axes[1, idx].hist(display_img.flatten(), bins=50, alpha=0.7, color=f'C{idx}')
        axes[1, idx].set_title(f'{name} 直方图', fontsize=10)
        axes[1, idx].set_xlabel('像素值')
        axes[1, idx].set_ylabel('频次')
        axes[1, idx].grid(True, alpha=0.3)
        
        # 第三行：显示与Raw NIR的差异图
        if name != 'Raw NIR':
            diff_img = np.abs(display_img.astype(float) - variants['Raw NIR'][:,:,0].astype(float))
            im = axes[2, idx].imshow(diff_img, cmap='hot')
            axes[2, idx].set_title(f'与Raw NIR差异\n均值差异: {diff_img.mean():.1f}', fontsize=10)
            axes[2, idx].axis('off')
            plt.colorbar(im, ax=axes[2, idx], shrink=0.6)
        else:
            axes[2, idx].text(0.5, 0.5, '参考图像', transform=axes[2, idx].transAxes, 
                             ha='center', va='center', fontsize=14)
            axes[2, idx].axis('off')
    
    plt.suptitle('NIR处理变体全面对比', fontsize=16)
    plt.tight_layout()
    
    save_path = 'nir_variants_comprehensive_test.png'
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"可视化结果已保存为: {save_path}")
    plt.close()

def test_tensor_conversion():
    """测试tensor转换是否正确"""
    print("\n" + "=" * 60)
    print("测试PyTorch Tensor转换")
    print("=" * 60)
    
    variants, _ = test_nir_processing_variants()
    
    print(f"{'变体名称':<15} {'Tensor形状':<20} {'均值':<12} {'标准差':<12} {'范围'}")
    print("-" * 80)
    
    for name, img in variants.items():
        # 转换为tensor（模拟eval_compare.py中的处理）
        if len(img.shape) == 3:
            tensor = torch.from_numpy(img.transpose(2,0,1) / 255.0).unsqueeze(0).float()
        else:
            img_3channel = np.stack([img]*3, axis=0)
            tensor = torch.from_numpy(img_3channel / 255.0).unsqueeze(0).float()
        
        print(f"{name:<15} {str(tensor.shape):<20} {tensor.mean():<12.6f} {tensor.std():<12.6f} [{tensor.min():.3f}, {tensor.max():.3f}]")
    
    print("\n✅ Tensor转换测试完成")

def provide_recommendations():
    """提供使用建议"""
    print("\n" + "=" * 70)
    print("使用建议和下一步操作")
    print("=" * 70)
    
    print("1. 如果上面显示'足够的差异':")
    print("   → 可以直接运行修复后的 eval_compare.py")
    print("   → 期望看到6张明显不同的图像结果")
    
    print("\n2. 如果上面显示'差异不足':")
    print("   → 需要在 eval_compare.py 中增加 enhancement_factor")
    print("   → 建议将 enhancement_factor 从 50.0 增加到 100.0 或更高")
    
    print("\n3. 检查生成的可视化图:")
    print("   → nir_variants_comprehensive_test.png")
    print("   → 确认Device Weighted明显不同于其他变体")
    
    print("\n4. 文件修改顺序:")
    print("   → 先用这个脚本确认处理差异足够大")
    print("   → 然后替换你的 eval_compare.py 文件")
    print("   → 最后运行评估获得正确的对比结果")

def main():
    """主测试函数"""
    print("NIR处理差异测试工具")
    print("作用：验证不同处理方法是否产生足够的差异用于对比评估")
    
    try:
        # 测试处理变体
        variants, sufficient_diff = test_nir_processing_variants()
        
        # 测试tensor转换
        test_tensor_conversion()
        
        # 提供建议
        provide_recommendations()
        
        if sufficient_diff:
            print(f"\n🎉 测试通过！可以进行有效的器件响应对比评估")
        else:
            print(f"\n⚠️  需要调整参数增加变体间差异")
            
    except Exception as e:
        print(f"测试过程中出现错误: {str(e)}")
        print("请检查依赖库是否正确安装: numpy, torch, cv2, matplotlib")

if __name__ == "__main__":
    main()