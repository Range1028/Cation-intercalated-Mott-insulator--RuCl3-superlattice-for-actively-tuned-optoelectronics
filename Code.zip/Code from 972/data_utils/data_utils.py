import torch.utils.data as data
import torchvision.transforms as tfs
from torchvision.transforms import functional as FF
import os
import random
from PIL import Image
from torch.utils.data import DataLoader
from matplotlib import pyplot as plt
from torchvision.utils import make_grid
from metrics import *
from option import opt
import numpy as np
import cv2


BS = opt.bs
print('batch size is:', BS)
crop_size = 'whole_img'
if opt.crop:
    crop_size = opt.crop_size    # (240,240)
else:
    crop_size = 'whole_img'


def tensorShow(tensors, titles=None):
    fig = plt.figure()
    for tensor, tit, i in zip(tensors, titles, range(len(tensors))):
        img = make_grid(tensor)
        npimg = img.numpy()
        ax = fig.add_subplot(211+i)
        ax.imshow(np.transpose(npimg, (1, 2, 0)))
        ax.set_title(tit)
    plt.show()


# ===== 新增: 器件加权高斯滤波函数 =====
def device_weighted_filter(nir_img, responsivity=0.003, ksize=5, sigma=1.0):
    """
    对红外通道做高斯加权滤波，结合器件在1550 nm的响应度
    nir_img: numpy array, shape=(H, W, 3)
    responsivity: 器件响应度 (A/W)
    ksize: 高斯核大小 (必须为奇数)
    sigma: 高斯核标准差
    """
    # 转灰度（保证与器件单通道响应对应）
    nir_gray = cv2.cvtColor(nir_img, cv2.COLOR_RGB2GRAY)
    # 高斯滤波
    nir_filtered = cv2.GaussianBlur(nir_gray, (ksize, ksize), sigma)
    # 响应度缩放
    nir_filtered = nir_filtered * responsivity
    # 扩展成3通道（保持和RGB输入一致）
    nir_filtered = np.stack([nir_filtered]*3, axis=-1)
    return nir_filtered.astype(np.float32)


class RGB_Dataset(data.Dataset):
    def __init__(self, path, train, size=crop_size, input_h=1080, input_w=1920):
        super(RGB_Dataset, self).__init__()
        self.size = size
        self.train = train
        self.input_h = input_h
        self.input_w = input_w

        # 验证路径
        if not os.path.exists(path):
            raise ValueError(f"Dataset path not found: {path}")

        self.haze_path = os.path.join(path, 'haze')
        self.clear_path = os.path.join(path, 'clear')
        self.nir_path = os.path.join(path, 'nir')

        # 验证子目录
        for p in [self.haze_path, self.clear_path, self.nir_path]:
            if not os.path.exists(p):
                raise ValueError(f"Subdirectory not found: {p}")

        self.haze_imgs_dir = os.listdir(self.haze_path)
        self.haze_imgs = [os.path.join(self.haze_path, img) for img in self.haze_imgs_dir]
        self.clear_dir = self.clear_path
        self.nir_dir = self.nir_path

    def __getitem__(self, index):
        try:
            haze_path = self.haze_imgs[index]
            id = os.path.basename(haze_path).split('_')[0]

            clear_name = f"{id}_rgb.png"
            nir_name = f"{id}_thermal_foggy_1.0.png"

            if not all(os.path.exists(p) for p in [
                haze_path,
                os.path.join(self.clear_dir, clear_name),
                os.path.join(self.nir_dir, nir_name)
            ]):
                raise FileNotFoundError(f"部分文件不存在: {id}")

            print(f"\r加载第 {index} 个样本...", end="", flush=True)

            haze = np.asarray(Image.open(haze_path).convert("RGB"))
            haze = np.asarray(Image.fromarray(haze).resize((self.input_w, self.input_h)),
                              dtype=np.float32).transpose((2, 0, 1)) / 255

            clear = np.asarray(Image.open(os.path.join(self.clear_dir, clear_name)).convert("RGB"))
            clear = np.asarray(Image.fromarray(clear).resize((self.input_w, self.input_h)),
                               dtype=np.float32).transpose((2, 0, 1)) / 255

            # ==== 原始 NIR ====
            nir_raw = np.asarray(Image.open(os.path.join(self.nir_dir, nir_name)).convert("RGB"))
            nir_raw = np.asarray(Image.fromarray(nir_raw).resize((self.input_w, self.input_h)))

            # ==== 新增: 器件加权滤波 ====
            nir_filtered = device_weighted_filter(nir_raw, responsivity=0.003, ksize=5, sigma=1.0)
            nir = nir_filtered.transpose((2, 0, 1)) / 255.0

            return torch.tensor(haze), torch.tensor(nir), torch.tensor(clear)

        except Exception as e:
            print(f"\n加载样本 {index} 时出错: {str(e)}")
            return None

    def __len__(self):
        return len(self.haze_imgs)


class val_Dataset(data.Dataset):
    def __init__(self, path, train, size=crop_size, input_h=1080, input_w=1920, format='.png'):
        super(val_Dataset, self).__init__()
        self.size = size
        print('crop size', size)
        self.train = train
        self.format = format
        self.input_h = input_h
        self.input_w = input_w
        
        # 验证路径
        if not os.path.exists(path):
            raise ValueError(f"Dataset path not found: {path}")
            
        self.haze_path = os.path.join(path, 'haze')
        self.clear_path = os.path.join(path, 'clear')  # 添加 clear 路径
        self.nir_path = os.path.join(path, 'nir')
        
        # 验证子目录
        for p in [self.haze_path, self.clear_path, self.nir_path]:
            if not os.path.exists(p):
                raise ValueError(f"Subdirectory not found: {p}")
                
        self.haze_imgs_dir = os.listdir(self.haze_path)
        self.haze_imgs = [os.path.join(self.haze_path, img) for img in self.haze_imgs_dir]
        self.clear_dir = os.path.join(path, 'clear')
        self.nir_dir = os.path.join(path, 'nir')

    def __getitem__(self, index):
        try:
            haze_path = self.haze_imgs[index]
            id = os.path.basename(haze_path).split('_')[0]
            
            clear_name = f"{id}_rgb.png"
            nir_name = f"{id}_thermal_foggy_1.0.png"
            
            print(f"\r正在加载验证集样本 {index}:", flush=True)
            print(f"  Haze: {haze_path}")
            print(f"  Clear: {os.path.join(self.clear_dir, clear_name)}")
            print(f"  NIR: {os.path.join(self.nir_dir, nir_name)}")
            
            # 验证所有文件是否存在
            if not all(os.path.exists(p) for p in [
                haze_path,
                os.path.join(self.clear_dir, clear_name),
                os.path.join(self.nir_dir, nir_name)
            ]):
                raise FileNotFoundError(f"部分文件不存在: {id}")
            
            haze = np.asarray(Image.open(haze_path).convert("RGB"))
            haze = np.asarray(Image.fromarray(haze).resize((self.input_w, self.input_h)),
                            dtype=np.float32).transpose((2, 0, 1)) / 255
            
            clear = np.asarray(Image.open(os.path.join(self.clear_dir, clear_name)).convert("RGB"))
            clear = np.asarray(Image.fromarray(clear).resize((self.input_w, self.input_h)),
                             dtype=np.float32).transpose((2, 0, 1)) / 255
            
            nir = np.asarray(Image.open(os.path.join(self.nir_dir, nir_name)).convert("RGB"))
            nir = np.asarray(Image.fromarray(nir).resize((self.input_w, self.input_h)),
                           dtype=np.float32).transpose((2, 0, 1)) / 255
            
            return torch.tensor(haze), torch.tensor(nir), torch.tensor(clear)
            
        except Exception as e:
            print(f"\n加载验证集样本 {index} 时出错: {str(e)}")
            raise

    def __len__(self):
        return len(self.haze_imgs)


path = '/root/autodl-tmp/VIFNet/Airsim-VID/foggy_1_0'  # 基础路径

# 修改数据加载器的创建方式
RGB_train_loader = DataLoader(
    dataset=RGB_Dataset(
        path=path+'/train',
        train=True
    ),
    batch_size=BS,
    shuffle=True
)

RGB_test_loader = DataLoader(
    dataset=RGB_Dataset(
        path=path+'/test',
        train=False
    ),
    batch_size=1,
    shuffle=False
)

RGB_val_loader = DataLoader(
    dataset=val_Dataset(
        path=path+'/val',
        train=False
    ),
    batch_size=1,
    shuffle=False
)
