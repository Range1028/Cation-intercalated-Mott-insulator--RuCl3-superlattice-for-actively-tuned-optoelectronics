import os, csv, math, argparse
import numpy as np
import torch
from torch import nn
from torchvision.utils import make_grid, save_image
import matplotlib.pyplot as plt
from torch.serialization import add_safe_globals

from option import opt
from metrics import psnr, ssim
from models.VIFnet import vifnet


from data_utils.data_utils import RGB_val_loader, device_weighted_filter

os.makedirs('eval_runs/figs', exist_ok=True)
os.makedirs('eval_runs/csv', exist_ok=True)

def to_device(x):
    return x.to(opt.device) if isinstance(x, torch.Tensor) else x


def select_variants_gui(default_selected=None):
    variants_list = ['rgb_only', 'raw_nir', 'gauss_only', 'device_weighted']
    if default_selected is None:
        default_selected = variants_list

    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.title('Select Variants to Process')
        root.geometry('320x260')
        root.resizable(False, False)

        tk.Label(root, text='Please select variants to process:').pack(anchor='w', padx=12, pady=(10, 6))

        var_map = {}
        for v in variants_list:
            iv = tk.IntVar(value=1 if v in default_selected else 0)
            cb = tk.Checkbutton(root, text=v, variable=iv)
            cb.pack(anchor='w', padx=16, pady=4)
            var_map[v] = iv

        chosen = []

        def on_ok():
            sel = [v for v in variants_list if var_map[v].get() == 1]
            if not sel:
                messagebox.showwarning('Notice', 'Please select at least one variant')
                return
            chosen.extend(sel)
            root.destroy()

        def on_cancel():
            root.destroy()

        btn_frame = tk.Frame(root)
        btn_frame.pack(fill='x', padx=12, pady=12)
        tk.Button(btn_frame, text='OK', width=10, command=on_ok).pack(side='left', padx=6)
        tk.Button(btn_frame, text='Cancel', width=10, command=on_cancel).pack(side='left', padx=6)

        try:
            root.update_idletasks()
            w = root.winfo_width(); h = root.winfo_height()
            x = (root.winfo_screenwidth() - w) // 2
            y = (root.winfo_screenheight() - h) // 3
            root.geometry(f'{w}x{h}+{x}+{y}')
        except Exception:
            pass

        root.mainloop()

        if chosen:
            return chosen
        return default_selected
    except Exception as e:
        print(f'GUI selection failed, falling back to CLI input: {e}')

    try:
        print('Available variants: rgb_only, raw_nir, gauss_only, device_weighted')
        line = input('Enter variants to process (comma-separated), press Enter for defaults: ').strip()
        if not line:
            return default_selected
        parts = [p.strip() for p in line.split(',') if p.strip() in variants_list]
        return parts or default_selected
    except Exception:
        return default_selected

def build_model():

    add_safe_globals(['numpy._core.multiarray.scalar'])

    net = vifnet(3,3).to(opt.device)
    if opt.device == 'cuda':
        net = torch.nn.DataParallel(net)

    try:
        ckpt_path = opt.model_dir + '.best' if os.path.exists(opt.model_dir + '.best') else opt.model_dir
        ckpt = torch.load(ckpt_path, map_location=opt.device)
    except Exception as e:
        print(f"Safe mode loading failed, trying compatibility mode: {str(e)}")
        ckpt = torch.load(ckpt_path, map_location=opt.device, weights_only=False)

    net.load_state_dict(ckpt['model'])
    net.eval()
    return net

@torch.no_grad()
def run_eval_variant(net, loader, variant_name, sample_save_dir=None, responsivity=0.003, ksize=5, sigma=1.0):
    ssims, psnrs = [], []
    sample_results = []
    example_panels = []
    for i, (haze, nir, gt) in enumerate(loader):
        haze = haze.float()/1.0
        nir  = nir.float()/1.0
        gt   = gt.float()/1.0
        haze, nir, gt = to_device(haze), to_device(nir), to_device(gt)

        if variant_name == 'rgb_only':
            nir_mod = torch.zeros_like(nir)
        elif variant_name == 'raw_nir':
            nir_mod = nir
        elif variant_name == 'gauss_only':
            nir_np = (nir[0].permute(1,2,0).cpu().numpy()*255).astype(np.uint8)
            nir_gauss = device_weighted_filter(nir_np, responsivity=1.0, ksize=ksize, sigma=sigma)
            nir_mod = torch.from_numpy(nir_gauss.transpose(2,0,1)/255.0).unsqueeze(0).to(opt.device)
        elif variant_name == 'device_weighted':
            nir_np = (nir[0].permute(1,2,0).cpu().numpy()*255).astype(np.uint8)
            nir_dev = device_weighted_filter(nir_np, responsivity=responsivity, ksize=ksize, sigma=sigma)
            nir_mod = torch.from_numpy(nir_dev.transpose(2,0,1)/255.0).unsqueeze(0).to(opt.device)
        else:
            raise ValueError("Unknown variant")

        pred, *_ = net(haze, nir_mod)

        s = ssim(pred, gt).item()
        p = psnr(pred, gt)
        ssims.append(s); psnrs.append(p)

        sample_name = f"sample_{i:04d}"
        try:
            if hasattr(loader.dataset, 'haze_imgs') and i < len(loader.dataset.haze_imgs):
                sample_name = os.path.basename(loader.dataset.haze_imgs[i]).split('.')[0]
        except:
            pass

        sample_result = {
            'sample_id': i,
            'sample_name': sample_name,
            'variant': variant_name,
            'ssim': s,
            'psnr': p,
            'responsivity': responsivity,
            'ksize': ksize,
            'sigma': sigma
        }
        sample_results.append(sample_result)

        if sample_save_dir:
            os.makedirs(f'{sample_save_dir}/{variant_name}', exist_ok=True)
            save_image(pred[0], f'{sample_save_dir}/{variant_name}/pred_{i}.png')

        if i < 3:
            example_panels.append((haze[0].cpu(), pred[0].cpu(), gt[0].cpu()))

    return float(np.mean(ssims)), float(np.mean(psnrs)), example_panels, sample_results

def paired_t_test(a, b):
    a, b = np.array(a), np.array(b)
    diff = a - b
    mean = diff.mean()
    std  = diff.std(ddof=1) + 1e-12
    n    = len(diff)
    tval = mean / (std / math.sqrt(n))
    return tval

def main():
    print("Loading model...")
    net = build_model()
    loader = RGB_val_loader

    variant_configs = {
        'rgb_only': {'responsivity': 0.003},
        'raw_nir': {'responsivity': 0.003},
        'gauss_only': {'responsivity': 1.0},
        'device_weighted': {'responsivity': 0.003},
    }

    selected_names = select_variants_gui(default_selected=list(variant_configs.keys()))
    ordered_all = list(variant_configs.keys())
    selected_names = [v for v in ordered_all if v in set(selected_names)]

    if not selected_names:
        print('No variants selected, exiting.')
        return

    print('Processing the following variants:', ', '.join(selected_names))

    variants = [(name, variant_configs[name]) for name in selected_names]

    results = {}
    all_sample_results = []

    for name, kw in variants:
        print(f"==> Evaluating: {name}")
        mssim, mpsnr, panels, sample_results = run_eval_variant(
            net, loader, name, sample_save_dir='eval_runs/preds', **kw
        )
        results[name] = {'SSIM': mssim, 'PSNR': mpsnr, 'panels': panels}
        all_sample_results.extend(sample_results)
        print(f"{name}: SSIM={mssim:.4f}, PSNR={mpsnr:.2f}")

    csv_path = 'eval_runs/csv/summary.csv'
    with open(csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Variant','SSIM','PSNR'])
        for k in selected_names:
            w.writerow([k, f"{results[k]['SSIM']:.4f}", f"{results[k]['PSNR']:.2f}"])
    print(f"Saved: {csv_path}")

    detailed_csv_path = 'eval_runs/csv/detailed_results.csv'
    with open(detailed_csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Sample_ID', 'Sample_Name', 'Variant', 'SSIM', 'PSNR', 'Responsivity', 'Kernel_Size', 'Sigma'])
        for result in all_sample_results:
            w.writerow([
                result['sample_id'],
                result['sample_name'],
                result['variant'],
                f"{result['ssim']:.6f}",
                f"{result['psnr']:.4f}",
                result['responsivity'],
                result['ksize'],
                result['sigma']
            ])
    print(f"Saved detailed results: {detailed_csv_path}")

    sample_comparison_csv = 'eval_runs/csv/sample_comparison.csv'
    from collections import defaultdict
    samples_by_id = defaultdict(dict)
    for result in all_sample_results:
        sample_id = result['sample_id']
        variant = result['variant']
        samples_by_id[sample_id][variant] = {
            'sample_name': result['sample_name'],
            'ssim': result['ssim'],
            'psnr': result['psnr']
        }

    with open(sample_comparison_csv, 'w', newline='') as f:
        w = csv.writer(f)
        header = ['Sample_ID', 'Sample_Name'] + \
                [f'{variant}_SSIM' for variant in selected_names] + \
                [f'{variant}_PSNR' for variant in selected_names]
        w.writerow(header)

        for sample_id in sorted(samples_by_id.keys()):
            sample_data = samples_by_id[sample_id]
            sample_name = next(iter(sample_data.values()))['sample_name'] if sample_data else f'sample_{sample_id:04d}'

            row = [sample_id, sample_name]
            for variant in selected_names:
                if variant in sample_data:
                    row.append(f"{sample_data[variant]['ssim']:.6f}")
                else:
                    row.append('N/A')
            for variant in selected_names:
                if variant in sample_data:
                    row.append(f"{sample_data[variant]['psnr']:.4f}")
                else:
                    row.append('N/A')
            w.writerow(row)

    print(f"Saved sample comparison: {sample_comparison_csv}")

    labels = list(selected_names)
    ssim_vals = [results[k]['SSIM'] for k in labels]
    psnr_vals = [results[k]['PSNR'] for k in labels]

    plt.figure()
    plt.bar(labels, ssim_vals)
    plt.title('SSIM by Variant'); plt.ylabel('SSIM'); plt.xticks(rotation=20)
    plt.tight_layout(); plt.savefig('eval_runs/figs/ssim_bar.png', dpi=200)

    plt.figure()
    plt.bar(labels, psnr_vals)
    plt.title('PSNR by Variant'); plt.ylabel('PSNR (dB)'); plt.xticks(rotation=20)
    plt.tight_layout(); plt.savefig('eval_runs/figs/psnr_bar.png', dpi=200)
    print("Saved: eval_runs/figs/ssim_bar.png, psnr_bar.png")

    print("Rendering example panels...")
    panels_per_sample = []
    for i in range(3):
        panels_per_sample.append({})

    for name, kw in variants:
        print(f"\nProcessing examples for variant {name}...")
        mssim, mpsnr, panels, _ = run_eval_variant(net, loader, name, **kw)
        for i in range(min(3, len(panels))):
            haze, pred, gt = panels[i]
            panels_per_sample[i][name] = {'haze': haze, 'pred': pred, 'gt': gt}

    for i, pack in enumerate(panels_per_sample):
        try:
            if not pack:
                print(f"Warning: Sample {i} has no available variants")
                continue

            names = list(selected_names)
            missing = [n for n in names if n not in pack]
            if missing:
                print(f"Sample {i} is missing these variants: {missing}")

            first_key = next(iter(pack.keys()))
            haze = pack[first_key]['haze']
            gt = pack[first_key]['gt']

            preds = [pack[n]['pred'] for n in names if n in pack]
            present_names = [n for n in names if n in pack]

            row = torch.stack([haze, *preds, gt], dim=0)
            n_cols = len(present_names) + 2
            grid = make_grid(row, nrow=n_cols, padding=2, normalize=True)

            save_path = f'eval_runs/figs/sample_{i+1}_panel.png'
            save_image(grid, save_path)
            print(f"Saved example panel: {save_path}")

            single_names = ['haze'] + present_names + ['gt']
            single_imgs = [haze] + preds + [gt]
            for idx, (img, n) in enumerate(zip(single_imgs, single_names)):
                single_path = f'eval_runs/figs/sample_{i+1}_{n}.png'
                save_image(img, single_path)
                print(f"Saved single image: {single_path}")

        except Exception as e:
            print(f"Error processing sample {i}: {str(e)}")
            continue

    print("\nEvaluation complete!")
    print("Please check the result images in eval_runs/figs directory")

if __name__ == "__main__":
    main()
