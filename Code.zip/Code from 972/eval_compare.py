# eval_compare.py
import os, csv, math, argparse
import numpy as np
import torch
from torch import nn
from torchvision.utils import make_grid, save_image
import matplotlib.pyplot as plt
from torch.serialization import add_safe_globals

from option import opt
from metrics import psnr, ssim
from models.VIFnet import vifnet

# === 复用你现有的数据集，但在验证阶段对 NIR 做“变体替换” ===
from data_utils.data_utils import RGB_val_loader, device_weighted_filter  # 直接引用你文件里的val loader与滤波函数

os.makedirs('eval_runs/figs', exist_ok=True)
os.makedirs('eval_runs/csv', exist_ok=True)

def to_device(x):
    return x.to(opt.device) if isinstance(x, torch.Tensor) else x

# 新增：在开始处理前的GUI多选窗口（失败则回退到命令行）
def select_variants_gui(default_selected=None):
    """弹出一个简单的多选窗口，返回被勾选的变体列表。
    回退：若GUI不可用，则改为命令行输入；若仍无选择，返回默认集合。
    """
    variants_list = ['rgb_only', 'raw_nir', 'gauss_only', 'device_weighted']
    if default_selected is None:
        default_selected = variants_list

    # 优先尝试 GUI
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.title('选择要处理的变体')
        root.geometry('320x260')
        root.resizable(False, False)

        tk.Label(root, text='请选择需要处理的变体：').pack(anchor='w', padx=12, pady=(10, 6))

        var_map = {}
        for v in variants_list:
            iv = tk.IntVar(value=1 if v in default_selected else 0)
            cb = tk.Checkbutton(root, text=v, variable=iv)
            cb.pack(anchor='w', padx=16, pady=4)
            var_map[v] = iv

        chosen = []

        def on_ok():
            sel = [v for v in variants_list if var_map[v].get() == 1]
            if not sel:
                messagebox.showwarning('提示', '请至少选择一个变体')
                return
            chosen.extend(sel)
            root.destroy()

        def on_cancel():
            root.destroy()

        btn_frame = tk.Frame(root)
        btn_frame.pack(fill='x', padx=12, pady=12)
        tk.Button(btn_frame, text='确定', width=10, command=on_ok).pack(side='left', padx=6)
        tk.Button(btn_frame, text='取消', width=10, command=on_cancel).pack(side='left', padx=6)

        # 居中显示
        try:
            root.update_idletasks()
            w = root.winfo_width(); h = root.winfo_height()
            x = (root.winfo_screenwidth() - w) // 2
            y = (root.winfo_screenheight() - h) // 3
            root.geometry(f'{w}x{h}+{x}+{y}')
        except Exception:
            pass

        root.mainloop()

        if chosen:
            return chosen
        # 若点了取消或窗口关闭，返回默认集合
        return default_selected
    except Exception as e:
        print(f'GUI 选择失败，回退到命令行输入: {e}')

    # 回退到命令行输入
    try:
        print('可选变体: rgb_only, raw_nir, gauss_only, device_weighted')
        line = input('请输入要处理的变体（以逗号分隔），直接回车则使用默认: ').strip()
        if not line:
            return default_selected
        parts = [p.strip() for p in line.split(',') if p.strip() in variants_list]
        return parts or default_selected
    except Exception:
        return default_selected

def build_model():
    # 添加安全全局变量
    add_safe_globals(['numpy._core.multiarray.scalar'])
    
    net = vifnet(3,3).to(opt.device)
    if opt.device == 'cuda':
        net = torch.nn.DataParallel(net)
    
    # 修改加载检查点的代码
    try:
        # 首先尝试使用新的安全模式加载
        ckpt_path = opt.model_dir + '.best' if os.path.exists(opt.model_dir + '.best') else opt.model_dir
        ckpt = torch.load(ckpt_path, map_location=opt.device)
    except Exception as e:
        print(f"安全模式加载失败，尝试使用兼容模式: {str(e)}")
        # 如果失败，使用兼容模式
        ckpt = torch.load(ckpt_path, map_location=opt.device, weights_only=False)
    
    net.load_state_dict(ckpt['model'])
    net.eval()
    return net

@torch.no_grad()
def run_eval_variant(net, loader, variant_name, sample_save_dir=None, responsivity=0.003, ksize=5, sigma=1.0):
    """variant_name ∈ {'rgb_only','raw_nir','gauss_only','device_weighted'}"""
    ssims, psnrs = [], []
    sample_results = []  # 保存每个样本的详细结果
    example_panels = []  # 保存部分可视化
    for i, (haze, nir, gt) in enumerate(loader):
        haze = haze.float()/1.0
        nir  = nir.float()/1.0
        gt   = gt.float()/1.0
        haze, nir, gt = to_device(haze), to_device(nir), to_device(gt)

        # --- 根据变体修改 NIR ---
        if variant_name == 'rgb_only':
            nir_mod = torch.zeros_like(nir)
        elif variant_name == 'raw_nir':
            nir_mod = nir  # 不做滤波/响应
        elif variant_name == 'gauss_only':
            # 把 NIR 取回CPU→numpy做高斯，再不乘响应度
            nir_np = (nir[0].permute(1,2,0).cpu().numpy()*255).astype(np.uint8)
            nir_gauss = device_weighted_filter(nir_np, responsivity=1.0, ksize=ksize, sigma=sigma)  # “1.0”代表不考虑响应度的纯高斯
            nir_mod = torch.from_numpy(nir_gauss.transpose(2,0,1)/255.0).unsqueeze(0).to(opt.device)
        elif variant_name == 'device_weighted':
            nir_np = (nir[0].permute(1,2,0).cpu().numpy()*255).astype(np.uint8)
            nir_dev = device_weighted_filter(nir_np, responsivity=responsivity, ksize=ksize, sigma=sigma)
            nir_mod = torch.from_numpy(nir_dev.transpose(2,0,1)/255.0).unsqueeze(0).to(opt.device)
        else:
            raise ValueError("Unknown variant")

        # --- 推理 ---
        pred, *_ = net(haze, nir_mod)

        # --- 度量 ---
        s = ssim(pred, gt).item()
        p = psnr(pred, gt)
        ssims.append(s); psnrs.append(p)
        
        # --- 保存每个样本的结果 ---
        # 尝试从dataset中获取文件名信息
        sample_name = f"sample_{i:04d}"  # 默认名称
        try:
            if hasattr(loader.dataset, 'haze_imgs') and i < len(loader.dataset.haze_imgs):
                sample_name = os.path.basename(loader.dataset.haze_imgs[i]).split('.')[0]
        except:
            pass
            
        sample_result = {
            'sample_id': i,
            'sample_name': sample_name,
            'variant': variant_name,
            'ssim': s,
            'psnr': p,
            'responsivity': responsivity,
            'ksize': ksize,
            'sigma': sigma
        }
        sample_results.append(sample_result)
        
        # --- 保存单独的预测图像 ---
        if sample_save_dir:
            os.makedirs(f'{sample_save_dir}/{variant_name}', exist_ok=True)
            save_image(pred[0], f'{sample_save_dir}/{variant_name}/pred_{i}.png')

        # --- 可视化：挑头3张做五联图（Haze / RGB-only / Raw NIR / Gauss / Device / GT） ---
        if i < 3:
            # 为了横向对比：我们需要四种variant，同时又不想重复前向多次 → 简单做法是外层多跑几次或在外面统一绘制
            # 这里仅存当前variant的pred，最终汇总绘图时再拼。
            example_panels.append((haze[0].cpu(), pred[0].cpu(), gt[0].cpu()))

    return float(np.mean(ssims)), float(np.mean(psnrs)), example_panels, sample_results

def paired_t_test(a, b):
    # 简单实现配对 t 检验（a,b是同一批样本的指标），这里用近似：mean/std/√n
    a, b = np.array(a), np.array(b)
    diff = a - b
    mean = diff.mean()
    std  = diff.std(ddof=1) + 1e-12
    n    = len(diff)
    tval = mean / (std / math.sqrt(n))
    # 不严格计算p，这里给出t统计量，实际可用scipy.stats.ttest_rel
    return tval

def main():
    print("Loading model...")
    net = build_model()
    loader = RGB_val_loader  # 直接使用你在 data_utils.py 里定义的 val loader

    # 变体配置
    variant_configs = {
        'rgb_only': {'responsivity': 0.003},
        'raw_nir': {'responsivity': 0.003},
        'gauss_only': {'responsivity': 1.0},
        'device_weighted': {'responsivity': 0.003},
    }

    # 弹出选择窗口，选择需要处理的变体
    selected_names = select_variants_gui(default_selected=list(variant_configs.keys()))
    # 去重并保持原始顺序
    ordered_all = list(variant_configs.keys())
    selected_names = [v for v in ordered_all if v in set(selected_names)]

    if not selected_names:
        print('未选择任何变体，程序已退出。')
        return

    print('将处理以下变体:', ', '.join(selected_names))

    # 逐变体评估（仅处理已选项）
    variants = [(name, variant_configs[name]) for name in selected_names]

    results = {}
    all_sample_results = []  # 存储所有样本的详细结果
    
    for name, kw in variants:
        print(f"==> Evaluating: {name}")
        mssim, mpsnr, panels, sample_results = run_eval_variant(
            net, loader, name, sample_save_dir='eval_runs/preds', **kw
        )
        results[name] = {'SSIM': mssim, 'PSNR': mpsnr, 'panels': panels}
        all_sample_results.extend(sample_results)
        print(f"{name}: SSIM={mssim:.4f}, PSNR={mpsnr:.2f}")

    # 导出总结CSV（仅包含已选变体）
    csv_path = 'eval_runs/csv/summary.csv'
    with open(csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Variant','SSIM','PSNR'])
        for k in selected_names:
            w.writerow([k, f"{results[k]['SSIM']:.4f}", f"{results[k]['PSNR']:.2f}"])
    print(f"Saved: {csv_path}")
    
    # 导出详细的所有样本结果CSV
    detailed_csv_path = 'eval_runs/csv/detailed_results.csv'
    with open(detailed_csv_path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['Sample_ID', 'Sample_Name', 'Variant', 'SSIM', 'PSNR', 'Responsivity', 'Kernel_Size', 'Sigma'])
        for result in all_sample_results:
            w.writerow([
                result['sample_id'],
                result['sample_name'],
                result['variant'],
                f"{result['ssim']:.6f}",
                f"{result['psnr']:.4f}",
                result['responsivity'],
                result['ksize'],
                result['sigma']
            ])
    print(f"Saved detailed results: {detailed_csv_path}")
    
    # 生成按样本分组的结果对比表
    sample_comparison_csv = 'eval_runs/csv/sample_comparison.csv'
    # 将结果按sample_id分组
    from collections import defaultdict
    samples_by_id = defaultdict(dict)
    for result in all_sample_results:
        sample_id = result['sample_id']
        variant = result['variant']
        samples_by_id[sample_id][variant] = {
            'sample_name': result['sample_name'],
            'ssim': result['ssim'],
            'psnr': result['psnr']
        }
    
    # 导出样本对比表（仅包含已选变体）
    with open(sample_comparison_csv, 'w', newline='') as f:
        w = csv.writer(f)
        header = ['Sample_ID', 'Sample_Name'] + \
                [f'{variant}_SSIM' for variant in selected_names] + \
                [f'{variant}_PSNR' for variant in selected_names]
        w.writerow(header)
        
        for sample_id in sorted(samples_by_id.keys()):
            sample_data = samples_by_id[sample_id]
            sample_name = next(iter(sample_data.values()))['sample_name'] if sample_data else f'sample_{sample_id:04d}'
            
            row = [sample_id, sample_name]
            # 添加SSIM值
            for variant in selected_names:
                if variant in sample_data:
                    row.append(f"{sample_data[variant]['ssim']:.6f}")
                else:
                    row.append('N/A')
            # 添加PSNR值
            for variant in selected_names:
                if variant in sample_data:
                    row.append(f"{sample_data[variant]['psnr']:.4f}")
                else:
                    row.append('N/A')
            w.writerow(row)
    
    print(f"Saved sample comparison: {sample_comparison_csv}")

    # 简单柱状图（仅包含已选变体）
    labels = list(selected_names)
    ssim_vals = [results[k]['SSIM'] for k in labels]
    psnr_vals = [results[k]['PSNR'] for k in labels]

    plt.figure()
    plt.bar(labels, ssim_vals)
    plt.title('SSIM by Variant'); plt.ylabel('SSIM'); plt.xticks(rotation=20)
    plt.tight_layout(); plt.savefig('eval_runs/figs/ssim_bar.png', dpi=200)

    plt.figure()
    plt.bar(labels, psnr_vals)
    plt.title('PSNR by Variant'); plt.ylabel('PSNR (dB)'); plt.xticks(rotation=20)
    plt.tight_layout(); plt.savefig('eval_runs/figs/psnr_bar.png', dpi=200)
    print("Saved: eval_runs/figs/ssim_bar.png, psnr_bar.png")

    # 多联图（Haze + 所选输出 + GT）
    print("Rendering example panels...")
    panels_per_sample = []
    for i in range(3): 
        panels_per_sample.append({})

    for name, kw in variants:
        print(f"\n处理变体 {name} 的示例...")
        mssim, mpsnr, panels, _ = run_eval_variant(net, loader, name, **kw)
        for i in range(min(3, len(panels))):
            haze, pred, gt = panels[i]
            panels_per_sample[i][name] = {'haze': haze, 'pred': pred, 'gt': gt}

    for i, pack in enumerate(panels_per_sample):
        try:
            # 确保至少有一个变体
            if not pack:
                print(f"警告：样本 {i} 没有可用的变体")
                continue

            names = list(selected_names)
            missing = [n for n in names if n not in pack]
            if missing:
                print(f"样本 {i} 缺少这些变体: {missing}")

            # 从第一个已存在的变体获取 haze 和 gt
            first_key = next(iter(pack.keys()))
            haze = pack[first_key]['haze']
            gt = pack[first_key]['gt']
            
            # 仅收集已存在的预测
            preds = [pack[n]['pred'] for n in names if n in pack]
            present_names = [n for n in names if n in pack]
            
            # 构建完整行：haze + 已选变体输出 + gt
            row = torch.stack([haze, *preds, gt], dim=0)
            n_cols = len(present_names) + 2
            grid = make_grid(row, nrow=n_cols, padding=2, normalize=True)
            
            # 保存多联图
            save_path = f'eval_runs/figs/sample_{i+1}_panel.png'
            save_image(grid, save_path)
            print(f"保存示例面板: {save_path}")

            # 保存每一张单图
            single_names = ['haze'] + present_names + ['gt']
            single_imgs = [haze] + preds + [gt]
            for idx, (img, n) in enumerate(zip(single_imgs, single_names)):
                single_path = f'eval_runs/figs/sample_{i+1}_{n}.png'
                save_image(img, single_path)
                print(f"保存单图: {single_path}")

        except Exception as e:
            print(f"处理样本 {i} 时出错: {str(e)}")
            continue

    print("\n评估完成！")
    print("请查看 eval_runs/figs 目录下的结果图像")

if __name__ == "__main__":
    main()
